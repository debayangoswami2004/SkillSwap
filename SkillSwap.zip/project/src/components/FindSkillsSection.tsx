import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabaseClient';
import { Search, MessageCircle, Video } from 'lucide-react';

interface UserSkill {
  profiles: {
    id: string;
    username: string;
    full_name: string;
    avatar_url: string;
  };
  skill_name: string;
  is_teaching: boolean;
}

const FindSkillsSection = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [users, setUsers] = useState<UserSkill[]>([]);
  const [loading, setLoading] = useState(false);

  const searchUsers = async (query: string) => {
    if (!query.trim()) {
      setUsers([]);
      return;
    }

    setLoading(true);
    const { data, error } = await supabase
      .from('user_skills')
      .select(`
        skill_name,
        is_teaching,
        profiles (
          id,
          username,
          full_name,
          avatar_url
        )
      `)
      .ilike('skill_name', `%${query}%`);

    if (!error && data) {
      setUsers(data as UserSkill[]);
    }
    setLoading(false);
  };

  useEffect(() => {
    const debounceTimer = setTimeout(() => {
      searchUsers(searchQuery);
    }, 300);

    return () => clearTimeout(debounceTimer);
  }, [searchQuery]);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8">Find Skills</h1>

      <div className="relative mb-8">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search for skills..."
          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />
      </div>

      {loading ? (
        <div className="text-center py-8">
          <div className="text-gray-600">Searching...</div>
        </div>
      ) : (
        <div className="space-y-6">
          {users.map((user, index) => (
            <div
              key={`${user.profiles.id}-${index}`}
              className="bg-white rounded-lg shadow-md p-6"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-full bg-gray-200 overflow-hidden">
                    {user.profiles.avatar_url ? (
                      <img
                        src={user.profiles.avatar_url}
                        alt={user.profiles.username}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-indigo-100 text-indigo-600 text-xl font-semibold">
                        {user.profiles.username?.[0]?.toUpperCase() || '?'}
                      </div>
                    )}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">{user.profiles.full_name || user.profiles.username}</h3>
                    <p className="text-gray-600">
                      {user.is_teaching ? 'Teaching' : 'Learning'}: {user.skill_name}
                    </p>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button className="inline-flex items-center px-4 py-2 border border-indigo-600 rounded-md text-indigo-600 hover:bg-indigo-50">
                    <MessageCircle size={18} className="mr-2" />
                    Message
                  </button>
                  <button className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                    <Video size={18} className="mr-2" />
                    Start Session
                  </button>
                </div>
              </div>
            </div>
          ))}
          {!loading && searchQuery && users.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-600">No users found with matching skills</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default FindSkillsSection;