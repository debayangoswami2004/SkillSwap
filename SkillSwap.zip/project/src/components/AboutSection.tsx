import React from 'react';

const AboutSection = () => {
  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl mb-8">
            About SkillSwap
          </h2>
          <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
            SkillSwap is a community-driven platform where people can exchange their expertise
            and learn from each other. Whether you're a professional looking to diversify your
            skillset or a beginner seeking guidance, our platform connects you with the right
            people to help you grow.
          </p>
        </div>
        
        <div className="mt-20 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-4">Connect</h3>
            <p className="text-gray-600">Find people with complementary skills and interests.</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-4">Exchange</h3>
            <p className="text-gray-600">Share your knowledge and learn new skills in return.</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-4">Grow</h3>
            <p className="text-gray-600">Develop your abilities and expand your professional network.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;