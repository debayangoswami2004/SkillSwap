import React from 'react';
import { BookOpen, Users, MessageCircle, Rocket } from 'lucide-react';

const SkillsSection = () => {
  const skills = [
    {
      icon: <BookOpen className="w-8 h-8 text-indigo-600" />,
      title: "Learn Anything",
      description: "Access a diverse range of skills and knowledge from our community."
    },
    {
      icon: <Users className="w-8 h-8 text-indigo-600" />,
      title: "Expert Network",
      description: "Connect with skilled professionals across various domains."
    },
    {
      icon: <MessageCircle className="w-8 h-8 text-indigo-600" />,
      title: "Real-time Chat",
      description: "Communicate seamlessly with your learning partners."
    },
    {
      icon: <Rocket className="w-8 h-8 text-indigo-600" />,
      title: "Skill Growth",
      description: "Track your progress and celebrate learning milestones."
    }
  ];

  return (
    <section id="skills" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl mb-8">
            Featured Skills
          </h2>
          <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto mb-16">
            Discover the most popular skills being exchanged on our platform
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          {skills.map((skill, index) => (
            <div key={index} className="bg-gray-50 p-6 rounded-lg hover:shadow-lg transition duration-300">
              <div className="flex justify-center mb-4">
                {skill.icon}
              </div>
              <h3 className="text-xl font-semibold text-center mb-2">{skill.title}</h3>
              <p className="text-gray-600 text-center">{skill.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;