import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabaseClient';
import { Plus } from 'lucide-react';

interface Skill {
  id: string;
  skill_name: string;
  is_teaching: boolean;
}

const ProfileSection = () => {
  const [user, setUser] = useState<any>(null);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [newTeachSkill, setNewTeachSkill] = useState('');
  const [newLearnSkill, setNewLearnSkill] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkUser();
  }, []);

  const checkUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    setUser(user);
    if (user) {
      loadSkills();
    }
    setLoading(false);
  };

  const loadSkills = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from('user_skills')
      .select('*')
      .eq('user_id', user.id);

    setSkills(data || []);
  };

  const handleAddTeachSkill = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeachSkill.trim()) return;

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase
      .from('user_skills')
      .insert({
        user_id: user.id,
        skill_name: newTeachSkill.trim(),
        is_teaching: true,
        proficiency_level: 'Advanced'
      });

    setNewTeachSkill('');
    loadSkills();
  };

  const handleAddLearnSkill = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLearnSkill.trim()) return;

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase
      .from('user_skills')
      .insert({
        user_id: user.id,
        skill_name: newLearnSkill.trim(),
        is_teaching: false,
        proficiency_level: 'Beginner'
      });

    setNewLearnSkill('');
    loadSkills();
  };

  const handleDeleteSkill = async (skillId: string) => {
    await supabase
      .from('user_skills')
      .delete()
      .eq('id', skillId);

    loadSkills();
  };

  if (loading) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <div className="text-gray-600">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-[400px] flex items-center justify-center text-center px-4">
        <p className="text-gray-600">Sign in to manage your profile</p>
      </div>
    );
  }

  const teachingSkills = skills.filter(skill => skill.is_teaching);
  const learningSkills = skills.filter(skill => !skill.is_teaching);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8">Your Profile</h1>

      <div className="space-y-8">
        <div>
          <h2 className="text-xl font-semibold mb-4">Skills You Have</h2>
          <div className="flex flex-wrap gap-2 mb-4">
            {teachingSkills.map(skill => (
              <span
                key={skill.id}
                className="inline-flex items-center bg-indigo-100 text-indigo-800 px-3 py-1 rounded-full text-sm"
              >
                {skill.skill_name}
                <button
                  onClick={() => handleDeleteSkill(skill.id)}
                  className="ml-2 text-indigo-600 hover:text-indigo-800"
                >
                  ×
                </button>
              </span>
            ))}
          </div>
          <form onSubmit={handleAddTeachSkill} className="flex gap-2">
            <input
              type="text"
              value={newTeachSkill}
              onChange={(e) => setNewTeachSkill(e.target.value)}
              placeholder="Add a skill you can teach"
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button
              type="submit"
              className="inline-flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"
            >
              <Plus size={20} />
              Add
            </button>
          </form>
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-4">Skills You Want to Learn</h2>
          <div className="flex flex-wrap gap-2 mb-4">
            {learningSkills.map(skill => (
              <span
                key={skill.id}
                className="inline-flex items-center bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm"
              >
                {skill.skill_name}
                <button
                  onClick={() => handleDeleteSkill(skill.id)}
                  className="ml-2 text-purple-600 hover:text-purple-800"
                >
                  ×
                </button>
              </span>
            ))}
          </div>
          <form onSubmit={handleAddLearnSkill} className="flex gap-2">
            <input
              type="text"
              value={newLearnSkill}
              onChange={(e) => setNewLearnSkill(e.target.value)}
              placeholder="Add a skill you want to learn"
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button
              type="submit"
              className="inline-flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700"
            >
              <Plus size={20} />
              Add
            </button>
          </form>
        </div>

        <button
          onClick={() => {}}
          className="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors"
        >
          Save Profile
        </button>
      </div>
    </div>
  );
};

export default ProfileSection;