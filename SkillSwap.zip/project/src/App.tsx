import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import ProfileSection from './components/ProfileSection';
import AboutSection from './components/AboutSection';
import SkillsSection from './components/SkillsSection';
import ContactSection from './components/ContactSection';
import FindSkillsSection from './components/FindSkillsSection';
import Footer from './components/Footer';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={
              <>
                <HeroSection />
                <AboutSection />
                <SkillsSection />
                <ContactSection />
              </>
            } />
            <Route path="/profile" element={
              <div className="container mx-auto px-4 py-16">
                <ProfileSection />
              </div>
            } />
            <Route path="/find-skills" element={
              <div className="container mx-auto px-4 py-16">
                <FindSkillsSection />
              </div>
            } />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;